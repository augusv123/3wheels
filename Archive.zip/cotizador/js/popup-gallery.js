"use strict";
$(document).ready(function () {
  var isMobile = false;
  if (
    /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
      navigator.userAgent
    )
  ) {
    isMobile = true;
  }
  $(".lightbox-gallery").magnificPopup({
    delegate: "a",
    type: "image",
    tLoading: "Loading image #%curr%...",
    mainClass: "mfp-fade",
    gallery: { enabled: true, navigateByImgClick: true, preload: [0, 1] },
  });
  $(".simple-ajax-popup-align-top").magnificPopup({
    type: "ajax",
    alignTop: true,
    overflowY: "scroll",
    callbacks: {
      open: function () {
        $(".navbar .collapse").removeClass("in");
        $(".navbar a.dropdown-toggle").addClass("collapsed");
      },
    },
  });
  $(".popup-youtube, .popup-vimeo, .popup-gmaps").magnificPopup({
    disableOn: 700,
    type: "iframe",
    mainClass: "mfp-fade",
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false,
    callbacks: {
      open: function () {
        if (!isMobile) $("body").addClass("overflow-hidden");
      },
      close: function () {
        if (!isMobile) $("body").removeClass("overflow-hidden");
      },
    },
  });
  $(".popup-youtube-landing").magnificPopup({
    disableOn: 700,
    type: "iframe",
    mainClass: "mfp-fade",
    removalDelay: 160,
    preloader: false,
    blackbg: true,
    fixedContentPos: false,
    callbacks: {
      open: function () {
        if (!isMobile) $("body").addClass("overflow-hidden");
      },
      close: function () {
        if (!isMobile) $("body").removeClass("overflow-hidden");
      },
    },
  });
  $(".image-popup-no-margins").magnificPopup({
    type: "image",
    closeOnContentClick: true,
    fixedContentPos: true,
    mainClass: "mfp-no-margins mfp-with-zoom",
    image: { verticalFit: true },
    zoom: { enabled: true, duration: 300 },
  });
  $(".image-popup-vertical-fit").magnificPopup({
    type: "image",
    closeOnContentClick: true,
    mainClass: "mfp-img-mobile",
    image: { verticalFit: true },
  });


 
    

    

  $(".zoom-gallery").magnificPopup({
    delegate: "a",
    type: "image",
    mainClass: "mfp-with-zoom mfp-img-mobile",
    image: {
      verticalFit: true,
      titleSrc: function (item) {
        return (
          item.el.attr("title") +
          ' &middot; <a class="image-source-link" href="' +
          item.el.attr("data-source") +
          '" target="_blank">image source</a>'
        );
      },
    },
    gallery: { enabled: true },
    closeBtnInside: true, 
    closeOnContentClick: true ,
    zoom: {
      enabled: true,
      duration: 300,
      opener: function (element) {
        return element.find("img");
      },
    },
  });


  for (let i = 0; i < 10; i++) {
    $(".zoom-gallery-"+i).magnificPopup({
      delegate: "a",
      type: "image",
      mainClass: "mfp-with-zoom mfp-img-mobile",
      image: {
        verticalFit: true,
        titleSrc: function (item) {
          return (
            item.el.attr("title") +
            ' &middot; <a class="image-source-link" href="' +
            item.el.attr("data-source") +
            '" target="_blank">image source</a>'
          );
        },
      },
      gallery: { enabled: true , closeBtnInside : true },
      closeBtnInside: true, 
      closeOnContentClick: true ,
      zoom: {
        enabled: true,
        duration: 300,
        opener: function (element) {
          return element.find("img");
        },
      },
    });
  }



  $(".popup-with-form").magnificPopup({
    type: "inline",
    preloader: false,
    closeBtnInside: true,
    focus: "#name",
    callbacks: {
      beforeOpen: function () {
        if ($(window).width() < 700) {
          this.st.focus = false;
        } else {
          this.st.focus = "#name";
        }
      },
    },
  });
  $(".modal-popup").magnificPopup({
    type: "inline",
    preloader: false,
    blackbg: true,
  });
  $(document).on("click", ".popup-modal-dismiss", function (e) {
    e.preventDefault();
    $.magnificPopup.close();
  });
  $(".popup-with-zoom-anim").magnificPopup({
    type: "inline",
    fixedContentPos: false,
    fixedBgPos: true,
    overflowY: "auto",
    closeBtnInside: true,
    preloader: false,
    midClick: true,
    removalDelay: 300,
    blackbg: true,
    mainClass: "my-mfp-zoom-in",
  });
  $(".popup-with-move-anim").magnificPopup({
    type: "inline",
    fixedContentPos: false,
    fixedBgPos: true,
    overflowY: "auto",
    closeBtnInside: true,
    preloader: false,
    midClick: true,
    removalDelay: 300,
    blackbg: true,
    mainClass: "my-mfp-slide-bottom",
  });
});


    // background: white !important;
    // color: #949494 !important;
    // font-size: 40px;
    // position: absolute;
    // right: 20px;
    // top: 50px;